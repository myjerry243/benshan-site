const DETAILS={
  "BS-Q08": {
    "page": 4,
    "steps": [
      "prepare",
      "anodize",
      "rinse",
      "colorSeal"
    ],
    "bath": [
      [
        "BS-Q08",
        "10 g/L"
      ],
      [
        "h2so4",
        "160–170 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "23–29°C"
      ],
      [
        "time",
        "22–28 min / 15 μm"
      ],
      [
        "aluminium",
        "<16 g/L"
      ],
      [
        "voltage",
        "<18 V"
      ]
    ],
    "notes": [
      "q08"
    ]
  },
  "BS-H07": {
    "page": 5,
    "steps": [
      "prepare",
      "three",
      "rinse",
      "anodizeNext"
    ],
    "bath": [
      [
        "BS-H07",
        "60 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "time",
        "3–5 min"
      ]
    ],
    "notes": []
  },
  "BS-H02": {
    "page": 5,
    "steps": [
      "anodized",
      "electro",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "BS-H02",
        "40 g/L"
      ],
      [
        "h2so4",
        "15 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "voltage",
        "10–14 V"
      ],
      [
        "ph",
        "0.9–1.2"
      ],
      [
        "freeAcid",
        "15–18 g/L"
      ],
      [
        "time",
        "shade"
      ]
    ],
    "notes": [
      "h02"
    ]
  },
  "BS-H03": {
    "page": 6,
    "steps": [
      "etched",
      "desmut",
      "rinse",
      "anodizeNext"
    ],
    "bath": [
      [
        "BS-H03",
        "60 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–30°C"
      ],
      [
        "time",
        "30–60 s"
      ]
    ],
    "notes": []
  },
  "BS-H01": {
    "page": 6,
    "steps": [
      "anodized",
      "sealBath",
      "rinse",
      "inspect"
    ],
    "bath": [
      [
        "BS-H01 A",
        "3 g/L"
      ],
      [
        "BS-H01 B",
        "8 g/L"
      ],
      [
        "diWater",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "ph",
        "4.5–5"
      ],
      [
        "printedTime",
        "1–1.2 μm/min"
      ]
    ],
    "notes": [
      "sealUnit"
    ]
  },
  "BS-Q04": {
    "page": 6,
    "steps": [
      "prepare",
      "degrease",
      "rinse",
      "nextProcess"
    ],
    "bath": [
      [
        "BS-Q04",
        "40–60 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "time",
        "3–5 min"
      ]
    ],
    "notes": [
      "tempMissing"
    ]
  },
  "BS-Q07": {
    "page": 6,
    "steps": [
      "clean",
      "convert",
      "rinse",
      "powder"
    ],
    "bath": [
      [
        "BS-Q07",
        "30–40 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "room"
      ],
      [
        "time",
        "1–3 min"
      ],
      [
        "ph",
        "2.0+0.2"
      ]
    ],
    "notes": [
      "q07"
    ]
  },
  "BS-H09": {
    "page": 7,
    "steps": [
      "clean",
      "convert",
      "rinse",
      "powder"
    ],
    "bath": [
      [
        "BS-H09",
        "20 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "room"
      ],
      [
        "time",
        "1–3 min"
      ],
      [
        "ph",
        "2.0–2.5"
      ]
    ],
    "notes": []
  },
  "BS-H05": {
    "page": 7,
    "steps": [
      "fixture",
      "strip",
      "inspect"
    ],
    "bath": [
      [
        "BS-H05 A : BS-H05 B",
        "drums"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "time",
        "thickness"
      ]
    ],
    "notes": [
      "h05"
    ]
  },
  "BS-H06": {
    "page": 7,
    "steps": [
      "prepare",
      "polish",
      "rinse",
      "nextProcess"
    ],
    "bath": [
      [
        "h3po4",
        "70%"
      ],
      [
        "h2so498",
        "30%"
      ],
      [
        "BS-H06",
        "3%"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "90–100°C"
      ],
      [
        "density",
        ">1.85"
      ],
      [
        "aluminium",
        "30–40 g/L"
      ]
    ],
    "notes": [
      "h06"
    ]
  },
  "BS-Q01": {
    "page": 7,
    "steps": [
      "prepare",
      "degrease",
      "rinse",
      "nextProcess"
    ],
    "bath": [
      [
        "BS-Q01",
        "50–60 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "time",
        "3–5 min"
      ]
    ],
    "notes": []
  },
  "BS-H08": {
    "page": 8,
    "steps": [
      "prepare",
      "brightClean",
      "rinse",
      "nextProcess"
    ],
    "bath": [
      [
        "BS-H08",
        "100 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "time",
        "3–6 min"
      ]
    ],
    "notes": []
  },
  "BS-Q02": {
    "page": 8,
    "steps": [
      "prepare",
      "dewax",
      "rinse",
      "inspect"
    ],
    "bath": [
      [
        "BS-Q02",
        "90–100 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "50–60°C"
      ],
      [
        "time",
        "10–15 min"
      ]
    ],
    "notes": []
  },
  "BS-Q05": {
    "page": 8,
    "steps": [
      "prepare",
      "alkali",
      "rinse",
      "desmutNext"
    ],
    "bath": [
      [
        "BS-Q05",
        "20–30 g/L"
      ],
      [
        "naoh",
        "40–60 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "freeNaoh",
        "40–70 g/L"
      ],
      [
        "temperature",
        "50–60°C"
      ],
      [
        "time",
        "8–15 min"
      ]
    ],
    "notes": []
  },
  "BS-Q06": {
    "page": 8,
    "steps": [
      "prepare",
      "acidEtch",
      "rinse",
      "desmutNext"
    ],
    "bath": [
      [
        "BS-Q06",
        "15–20 g/L"
      ],
      [
        "nh4hf2",
        "70 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "nh4hf2",
        "60–80 g/L"
      ],
      [
        "temperature",
        "35–50°C"
      ],
      [
        "time",
        "3–7 min"
      ],
      [
        "ph",
        "2.8–3.5"
      ]
    ],
    "notes": []
  },
  "BS-Z01": {
    "page": 9,
    "steps": [
      "anodized",
      "electro",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "BS-Z01",
        "20 g/L"
      ],
      [
        "h2so4",
        "18 g/L"
      ],
      [
        "snso4",
        "8–15 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "voltage",
        "16–20 V"
      ],
      [
        "temperature",
        "20°C ±2"
      ],
      [
        "time",
        "shade"
      ],
      [
        "ph",
        "0.8–1.0"
      ]
    ],
    "notes": [
      "z01"
    ]
  },
  "BS-Z02": {
    "page": 9,
    "steps": [
      "anodized",
      "electro",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "BS-Z02",
        "30–35 g/L"
      ],
      [
        "h2so4",
        "18–22 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "voltage",
        "13–15 V"
      ],
      [
        "temperature",
        "40°C ±2"
      ],
      [
        "time",
        "shade"
      ],
      [
        "ph",
        "0.8–1.0"
      ]
    ],
    "notes": []
  },
  "BS-Z03": {
    "page": 9,
    "steps": [
      "anodized",
      "electro",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "BS-Z03",
        "8–10 g/L"
      ],
      [
        "h2so4",
        "18–22 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "voltage",
        "13–15 V"
      ],
      [
        "temperature",
        "18–25°C"
      ],
      [
        "time",
        "shade"
      ],
      [
        "ph",
        "0.8–1.0"
      ]
    ],
    "notes": []
  },
  "BS-Z04": {
    "page": 9,
    "steps": [
      "anodized",
      "electro",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "cuso4",
        "8–10 g/L"
      ],
      [
        "h2so4",
        "18–20 g/L"
      ],
      [
        "BS-Z04",
        "8–10 g/L"
      ],
      [
        "water",
        "balance"
      ]
    ],
    "conditions": [
      [
        "voltage",
        "13–15 V"
      ],
      [
        "temperature",
        "20°C ±2"
      ],
      [
        "time",
        "shade"
      ],
      [
        "ph",
        "0.8–1.0"
      ]
    ],
    "notes": []
  },
  "BS-D01": {
    "page": 9,
    "steps": [
      "anodized",
      "dye",
      "rinse",
      "seal"
    ],
    "bath": [
      [
        "BS-D01",
        "1–10 g/L"
      ]
    ],
    "conditions": [
      [
        "temperature",
        "20–35°C"
      ],
      [
        "time",
        "5–15 min"
      ],
      [
        "ph",
        "5–6"
      ]
    ],
    "notes": []
  },
  "BS-F01": {
    "page": 10,
    "steps": [
      "anodized",
      "sealBath",
      "rinse",
      "inspect"
    ],
    "bath": [
      [
        "BS-F01",
        "5 g/L"
      ]
    ],
    "conditions": [
      [
        "nickel",
        "0.8–1.2 g/L"
      ],
      [
        "fluoride",
        "0.3–0.8 g/L"
      ],
      [
        "ph",
        "5.8–6.5"
      ],
      [
        "temperature",
        "20–35°C"
      ],
      [
        "printedTime",
        "1–1.5 μm/min"
      ]
    ],
    "notes": [
      "sealUnit"
    ]
  },
  "BS-F02": {
    "page": 10,
    "steps": [
      "anodized",
      "sealBath",
      "rinse",
      "inspect"
    ],
    "bath": [
      [
        "BS-F02",
        "6–8 g/L"
      ]
    ],
    "conditions": [
      [
        "nickel",
        "0.8–1.2 g/L"
      ],
      [
        "ph",
        "5.8–6.5"
      ],
      [
        "temperature",
        "55–65°C"
      ],
      [
        "printedTime",
        "1–1.5 μm/min"
      ]
    ],
    "notes": [
      "sealUnit"
    ]
  },
  "BS-H04": {
    "page": 3,
    "steps": [
      "h04"
    ],
    "bath": [],
    "conditions": [],
    "notes": []
  }
};
const PURPOSES={
  "zh": [
    "用于铝型材阳极氧化槽，加快氧化膜形成。产品资料说明可缩短氧化时间、扩大工作温度范围，为后续电解着色或染色提供均匀、致密的氧化膜基底。",
    "用于铝型材阳极氧化前的砂面处理，将除油、碱蚀、中和功能合并。尤其针对油污较重的喷砂料，兼顾除油、增光和除灰；产品资料描述可减少铝损耗及水洗工序。",
    "用于阳极氧化铝材的黑色电解着色，以无锡体系获得均匀、明亮的珍珠黑效果。产品资料说明氧化膜厚度约 10 μm 即可着色，且无需添加硫酸亚锡。",
    "用于铝材碱蚀、酸蚀后的除灰和中和增光。去除表面残留的深灰或黑色沉积，同时改善表面亮度，为后续阳极氧化准备清洁表面。",
    "用于阳极氧化铝材的常温无镍封孔，由固体 A 剂与液体 B 剂配合使用。产品资料强调封孔质量、槽液抗杂质能力及较简便的工艺维护。",
    "用于铝型材喷粉或阳极氧化之前的清洗除油。表面活性剂与乳化组分帮助去除油脂、污渍和自然氧化膜，为后续处理提供洁净基面。",
    "用于铝型材粉末喷涂前的铬化转化处理。产品资料描述其在常温下生成淡黄色转化膜，以改善耐蚀性及铝材与后续涂层之间的结合力。",
    "用于铝型材粉末喷涂前的无铬转化成膜。常温下在铝表面形成透明转化膜，改善耐蚀性及与粉末涂层的附着结合。",
    "用于清除钢铁、不锈钢表面的涂层及油漆，特别适用于喷涂挂具和夹具上固化粉末涂层的脱除。产品资料正文的主要适用对象为钢制和不锈钢工件。",
    "用于高光、喷砂、拉丝等铝材表面的两酸抛光，与磷酸、硫酸体系配合。产品资料描述其不含硝酸，可获得平滑表面并改善槽液稳定性。",
    "用于铝型材喷粉或阳极氧化之前的清洗除油。表面活性剂与乳化组分帮助去除油脂、污渍和自然氧化膜，为后续处理提供洁净基面。",
    "用于铝材清洗增光，去除油脂、污渍及自然氧化膜。产品资料将其作为无氟抛光产品，强调相较传统含氟处理的低铝耗、表面增亮和废水处理便利性。",
    "用于金属工件的除蜡、除油清洗。水基配方通过乳化作用去除抛光蜡残留和油污，适用于需要清除残蜡并保护工件表面的清洗环节。",
    "用于铝材碱蚀槽，与氢氧化钠配合。通过络合铝离子帮助减少槽液结晶沉淀，改善表面质量，并减少铝损耗与氢氧化钠消耗。",
    "用于阳极氧化前的铝材酸蚀起砂，与氟化氢铵配合形成均匀、细致的砂面。通过改变表面形貌与粗糙度，为后续氧化处理准备基面。",
    "用于铝型材阳极氧化后的电解着色，可获得香槟色、古铜色及黑色。产品为易溶于水的粉末，产品资料强调槽液稳定、上色均匀及耐候性。",
    "用于阳极氧化铝型材的浅钛金色电解着色。透明液体配方用于控制色差和颜色一致性，适合需要钛金装饰效果的表面。",
    "用于阳极氧化铝材的金黄色电解着色，在光滑表面形成 18K 金色装饰效果。黑红色固体配方含分散、络合与导电组分；“18K”指外观色泽，不表示镀金含量。",
    "用于阳极氧化铝型材的紫铜色电解着色，产品资料特别提及建筑外墙装饰。蓝色粉末中的分散和络合组分旨在改善铜盐着色的边缘色差。",
    "用于阳极氧化铝材的浸渍染色，无需通电，可提供多种鲜艳颜色及定制配色。产品资料建议用于室内装饰类应用。",
    "用于阳极氧化铝材的常温封孔。浅绿色固体产品着重于槽液抗杂质能力、酸碱缓冲性和抑制封孔粉霜；产品资料参数表列有镍离子和氟离子控制范围。",
    "用于铝材阳极氧化、染色后的中温封孔，填充并封闭氧化膜孔隙，以改善耐蚀和耐磨表现，并抑制粉霜形成。产品资料参数表列有镍离子控制范围。",
    "无镍中温封孔剂. 产品资料未提供，请向本山确认。"
  ],
  "en": [
    "An anodizing-bath additive for aluminum profiles that accelerates oxide-film formation. The product information describes shorter anodizing cycles and a wider operating-temperature range, producing a uniform, dense base for subsequent electrolytic coloring or dyeing.",
    "A pretreatment for sandblasted aluminum that combines degreasing, alkaline-etching and neutralizing functions. Particularly intended for heavily oil-contaminated sandblasted profiles, it cleans, brightens and removes residues while reducing separate processing and rinse stages.",
    "A tin-free system for black electrolytic coloring of anodized aluminum. The product information describes a bright, uniform pearl-black finish on an oxide film of about 10 μm, without adding stannous sulfate.",
    "For desmutting after alkaline or acid etching of aluminum. It removes dark surface residues and improves brightness, preparing a clean surface for the next anodizing stage.",
    "A nickel-free, room-temperature sealing system for anodized aluminum, combining solid Component A and liquid Component B. The product information emphasizes stable sealing performance, tolerance to bath impurities and straightforward maintenance.",
    "For degreasing aluminum profiles before powder coating or anodizing. Surfactants and emulsifiers remove oil, grease, dirt and natural oxide films to prepare a clean surface for subsequent processing.",
    "A chromium conversion treatment before powder coating of aluminum. The product information describes formation of a light-yellow conversion film at room temperature to improve corrosion resistance and coating adhesion.",
    "A chromium-free conversion treatment before powder coating of aluminum. It forms a transparent conversion film at room temperature to improve corrosion resistance and the bond between aluminum and the powder coating.",
    "For removing paint and coatings from steel and stainless steel, especially cured powder coating on coating hangers and fixtures. Steel and stainless-steel substrates are the principal applications stated in the product information description.",
    "A dual-acid polishing additive for glossy, sandblasted and brushed aluminum, used in a phosphoric/sulfuric acid system. The product information describes a nitric-acid-free formulation for smooth finishes and improved bath stability.",
    "For degreasing aluminum profiles before powder coating or anodizing. Surfactants and emulsifiers remove oil, grease, dirt and natural oxide films to prepare a clean surface for subsequent processing.",
    "For cleaning and brightening aluminum while removing grease, dirt and natural oxide films. Listed as a fluoride-free polishing agent, it is described as reducing aluminum loss and simplifying wastewater treatment compared with conventional fluoride-containing treatment.",
    "A water-based cleaner for wax and oil residues on metal workpieces. Its emulsifying action removes polishing-wax contamination and grease in cleaning operations where the underlying surface must be protected.",
    "An additive for alkaline etching of aluminum, used with sodium hydroxide. It complexes aluminum ions to reduce crystallization and precipitation, improve surface quality and reduce aluminum and sodium-hydroxide consumption.",
    "For acid etching and matting aluminum before anodizing, used with ammonium bifluoride. It develops a uniform, fine matte finish by modifying surface texture and roughness before subsequent treatment.",
    "For electrolytic coloring of anodized aluminum in champagne, bronze and black shades. A water-soluble powder described as providing stable baths, even coloring and weather resistance.",
    "For light titanium-gold electrolytic coloring of anodized aluminum. The transparent liquid is intended to support color control and consistency on decorative surfaces.",
    "For golden electrolytic coloring of anodized aluminum, producing an 18K-gold appearance on smooth surfaces. The black-red solid contains dispersing, complexing and conductive components; “18K” describes the color, not a gold-plating content.",
    "For purple-copper electrolytic coloring of anodized aluminum, particularly architectural exterior decoration. Dispersing and complexing components in the blue powder are intended to reduce edge-color variation associated with copper-salt coloring.",
    "For immersion dyeing of anodized aluminum without electrical current. Offers multiple vibrant colors and custom color matching; the product information recommends indoor decorative applications.",
    "For room-temperature sealing of anodized aluminum. The light-green solid is described as offering impurity tolerance, acid/alkali buffering and resistance to sealing bloom. Its product information control table includes nickel and fluoride ions.",
    "For medium-temperature sealing after anodizing and dyeing, closing oxide-film pores to improve corrosion and wear performance and limit powdery bloom. Its product information control table includes nickel ions.",
    "Nickel-free medium-temperature sealing. Not provided in the product information; confirm with Benshan."
  ],
  "vi": [
    "Phụ gia cho bể anot hóa nhôm, giúp tạo màng oxit nhanh hơn. thông tin sản phẩm mô tả thời gian xử lý ngắn hơn và khoảng nhiệt độ rộng hơn, tạo nền màng đồng đều cho tạo màu điện phân hoặc nhuộm.",
    "Tiền xử lý nhôm phun cát, kết hợp tẩy dầu, ăn mòn kiềm và trung hòa. Đặc biệt phù hợp với nhôm phun cát nhiều dầu, giúp làm sạch, tăng sáng và giảm các công đoạn riêng lẻ.",
    "Hệ tạo màu điện phân đen không thiếc cho nhôm anot hóa. thông tin sản phẩm mô tả màu đen ngọc trai đồng đều trên màng khoảng 10 μm, không cần thêm thiếc(II) sunfat.",
    "Khử cặn đen sau ăn mòn kiềm hoặc axit trên nhôm. Loại bỏ cặn bề mặt và tăng độ sáng để chuẩn bị cho anot hóa.",
    "Hệ bịt kín không niken ở nhiệt độ thường cho nhôm anot hóa, dùng chất rắn A và chất lỏng B. thông tin sản phẩm nhấn mạnh độ ổn định, khả năng chịu tạp chất và bảo dưỡng đơn giản.",
    "Tẩy dầu nhôm trước sơn bột hoặc anot hóa. Chất hoạt động bề mặt và chất nhũ hóa giúp loại bỏ dầu, bụi bẩn và màng oxit tự nhiên.",
    "Chuyển hóa crom trước sơn bột nhôm. Tạo màng chuyển hóa vàng nhạt ở nhiệt độ thường nhằm cải thiện chống ăn mòn và độ bám sơn.",
    "Chuyển hóa không crom trước sơn bột nhôm. Tạo màng trong suốt ở nhiệt độ thường nhằm cải thiện chống ăn mòn và liên kết với lớp sơn.",
    "Tẩy sơn và lớp phủ trên thép, thép không gỉ, nhất là sơn bột đã đóng rắn trên móc và đồ gá. Đây là các vật liệu nền chính nêu trong thông tin sản phẩm.",
    "Phụ gia đánh bóng nhôm bóng, phun cát và xước bằng hệ axit photphoric/sulfuric. thông tin sản phẩm mô tả công thức không axit nitric, tạo bề mặt nhẵn và tăng ổn định bể.",
    "Tẩy dầu nhôm trước sơn bột hoặc anot hóa. Chất hoạt động bề mặt và chất nhũ hóa giúp loại bỏ dầu, bụi bẩn và màng oxit tự nhiên.",
    "Làm sạch và tăng sáng nhôm bằng cách loại bỏ dầu, bẩn và màng oxit tự nhiên. Sản phẩm đánh bóng không florua được mô tả giúp giảm hao nhôm và thuận tiện xử lý nước thải.",
    "Chất làm sạch gốc nước cho sáp và dầu trên kim loại. Nhũ hóa cặn sáp đánh bóng và dầu mỡ đồng thời bảo vệ bề mặt nền.",
    "Phụ gia ăn mòn kiềm nhôm dùng với natri hydroxit. Tạo phức ion nhôm giúp hạn chế kết tinh, kết tủa và giảm tiêu hao nhôm, kiềm.",
    "Ăn mòn axit tạo nhám nhôm trước anot hóa, dùng cùng amoni biflorua. Tạo bề mặt mờ mịn, đồng đều bằng cách điều chỉnh cấu trúc và độ nhám.",
    "Tạo màu điện phân nhôm anot hóa với màu champagne, đồng cổ và đen. Bột tan trong nước, được mô tả có bể ổn định và màu đồng đều.",
    "Tạo màu điện phân vàng titan nhạt cho nhôm anot hóa. Dạng lỏng trong suốt giúp kiểm soát màu và độ đồng nhất của bề mặt trang trí.",
    "Tạo màu điện phân vàng 18K trên nhôm anot hóa nhẵn. Chất rắn đen đỏ chứa thành phần phân tán, tạo phức và dẫn điện; 18K chỉ màu sắc, không phải hàm lượng mạ vàng.",
    "Tạo màu điện phân đồng tím cho nhôm anot hóa, đặc biệt trang trí ngoại thất. Thành phần phân tán và tạo phức trong bột xanh giúp giảm lệch màu ở mép.",
    "Nhuộm nhúng nhôm anot hóa không cần dòng điện. Có nhiều màu và phối màu theo yêu cầu; thông tin sản phẩm khuyến nghị trang trí nội thất.",
    "Bịt kín nhôm anot hóa ở nhiệt độ thường. Chất rắn xanh nhạt có tính đệm và chống đốm bột; bảng thông số có ion niken và florua.",
    "Bịt kín nhiệt độ trung bình sau anot hóa và nhuộm, đóng lỗ màng oxit để cải thiện chống ăn mòn, mài mòn và giảm phấn trắng. Bảng thông số có ion niken.",
    "Chất bịt kín không niken nhiệt độ trung bình. thông tin sản phẩm không cung cấp; xác nhận với Benshan."
  ],
  "id": [
    "Aditif bak anodisasi aluminium untuk mempercepat pembentukan lapisan oksida. Informasi produk menyebut waktu lebih singkat dan rentang suhu lebih luas, dengan lapisan merata untuk pewarnaan berikutnya.",
    "Praperlakuan aluminium sandblast yang menggabungkan penghilangan minyak, etsa alkali, dan netralisasi. Cocok untuk profil sangat berminyak, sekaligus membersihkan, mencerahkan, dan mengurangi tahap terpisah.",
    "Sistem pewarnaan elektrolitik hitam bebas timah untuk aluminium anodisasi. Informasi produk menyebut hasil hitam mutiara merata pada lapisan sekitar 10 μm tanpa timah(II) sulfat.",
    "Untuk menghilangkan residu gelap setelah etsa alkali atau asam. Membersihkan dan mencerahkan permukaan aluminium sebelum anodisasi.",
    "Sistem penyegelan bebas nikel suhu ruang untuk aluminium anodisasi dengan komponen padat A dan cair B. Informasi produk menekankan kestabilan, toleransi kotoran bak, dan kemudahan pemeliharaan.",
    "Menghilangkan minyak sebelum powder coating atau anodisasi aluminium. Surfaktan dan pengemulsi membersihkan lemak, kotoran, dan lapisan oksida alami.",
    "Konversi kromium sebelum powder coating aluminium. Membentuk lapisan kuning muda pada suhu ruang untuk meningkatkan ketahanan korosi dan adhesi cat.",
    "Konversi bebas kromium sebelum powder coating aluminium. Membentuk lapisan transparan pada suhu ruang untuk memperbaiki ketahanan korosi dan ikatan lapisan.",
    "Menghilangkan cat dan lapisan pada baja serta baja tahan karat, terutama powder coating mengeras pada gantungan dan jig. Kedua substrat tersebut merupakan aplikasi utama dalam informasi produk.",
    "Aditif pemoles dua asam untuk aluminium mengilap, sandblast, dan brushed dalam sistem asam fosfat/sulfat. Informasi produk menyebut formulasi tanpa asam nitrat dan kestabilan bak yang lebih baik.",
    "Menghilangkan minyak sebelum powder coating atau anodisasi aluminium. Surfaktan dan pengemulsi membersihkan lemak, kotoran, dan lapisan oksida alami.",
    "Membersihkan dan mencerahkan aluminium dengan menghilangkan minyak, kotoran, dan oksida alami. Pemoles bebas fluorida ini disebut mengurangi kehilangan aluminium dan memudahkan pengolahan limbah.",
    "Pembersih berbasis air untuk sisa lilin dan minyak pada logam. Mengemulsikan lilin pemoles dan lemak sambil melindungi permukaan benda kerja.",
    "Aditif etsa alkali aluminium yang digunakan bersama natrium hidroksida. Mengompleks ion aluminium untuk mengurangi kristalisasi, endapan, serta konsumsi aluminium dan alkali.",
    "Etsa asam untuk permukaan matte aluminium sebelum anodisasi, bersama amonium bifluorida. Mengubah tekstur dan kekasaran untuk menghasilkan matte halus merata.",
    "Pewarnaan elektrolitik aluminium anodisasi dalam warna champagne, perunggu, dan hitam. Serbuk larut air dengan kestabilan bak dan keseragaman warna menurut informasi produk.",
    "Pewarnaan elektrolitik emas titanium muda pada aluminium anodisasi. Cairan transparan membantu kontrol dan konsistensi warna dekoratif.",
    "Pewarnaan elektrolitik keemasan dengan tampilan emas 18K pada aluminium halus. Padatan hitam-merah mengandung pendispersi, pengompleks, dan penghantar; 18K menyatakan warna, bukan kadar lapisan emas.",
    "Pewarnaan elektrolitik tembaga ungu pada aluminium anodisasi, khususnya eksterior bangunan. Serbuk biru mengandung bahan yang membantu mengurangi perbedaan warna pada tepi.",
    "Pencelupan aluminium anodisasi tanpa arus listrik. Tersedia berbagai warna dan pencocokan khusus; informasi produk menyarankan dekorasi dalam ruangan.",
    "Penyegelan aluminium anodisasi pada suhu ruang. Padatan hijau muda dengan daya penyangga dan pengendalian bercak bubuk; tabel mencantumkan ion nikel dan fluorida.",
    "Penyegelan suhu sedang setelah anodisasi dan pewarnaan untuk menutup pori oksida, meningkatkan ketahanan korosi dan aus, serta menekan bercak bubuk. Tabel mencantumkan ion nikel.",
    "Penyegel bebas nikel suhu sedang. Tidak tercantum dalam informasi produk; konfirmasi ke Benshan."
  ],
  "ar": [
    "مضاف لحمام أنودة الألومنيوم يسرّع تكوين طبقة الأكسيد. يذكر بيانات المنتج تقليل زمن المعالجة وتوسيع مجال الحرارة مع طبقة منتظمة تمهّد للتلوين الكهربائي أو الصباغة.",
    "معالجة أولية للألومنيوم المسفوع بالرمل تجمع إزالة الشحوم والحفر القلوي والتعادل. تناسب القطع كثيرة الزيوت وتساعد على التنظيف والتفتيح وتقليل المراحل المنفصلة.",
    "نظام تلوين كهربائي أسود خالٍ من القصدير للألومنيوم المؤنود. يصف بيانات المنتج لونًا أسود لؤلؤيًا منتظمًا على طبقة تقارب 10 ميكرومتر دون إضافة كبريتات القصدير الثنائي.",
    "لإزالة الرواسب الداكنة بعد الحفر القلوي أو الحمضي للألومنيوم. ينظف السطح ويحسّن لمعانه استعدادًا للأنودة.",
    "نظام إغلاق مسام خالٍ من النيكل بدرجة الغرفة، بمكوّن صلب A وسائل B. يركز بيانات المنتج على ثبات الأداء وتحمل شوائب الحمام وسهولة الصيانة.",
    "لإزالة الشحوم قبل طلاء الألومنيوم بالمسحوق أو أنودته. تساعد المواد الخافضة للتوتر والمستحلبات على إزالة الزيوت والأوساخ وطبقة الأكسيد الطبيعية.",
    "معالجة تحويلية كرومية قبل الطلاء بالمسحوق. تتكون طبقة صفراء فاتحة بدرجة الغرفة لتحسين مقاومة التآكل والتصاق الطلاء.",
    "معالجة تحويلية خالية من الكروم قبل الطلاء بالمسحوق. تكوّن طبقة شفافة بدرجة الغرفة لتحسين مقاومة التآكل والترابط مع الطلاء.",
    "لإزالة الدهانات والطلاءات من الفولاذ والفولاذ المقاوم للصدأ، خصوصًا الطلاء المسحوق المتصلب على الحوامل والتجهيزات. هاتان هما الركيزتان الأساسيتان في وصف بيانات المنتج.",
    "مضاف تلميع بحمضين للألومنيوم اللامع والمسفوع والمصقول بالفرشاة ضمن نظام فوسفوريك/كبريتيك. يصف بيانات المنتج تركيبة دون حمض النتريك لتحسين النعومة وثبات الحمام.",
    "لإزالة الشحوم قبل طلاء الألومنيوم بالمسحوق أو أنودته. تساعد المواد الخافضة للتوتر والمستحلبات على إزالة الزيوت والأوساخ وطبقة الأكسيد الطبيعية.",
    "لتنظيف الألومنيوم وتفتيحه بإزالة الزيوت والأوساخ والأكسيد الطبيعي. يصف بيانات المنتج عامل التلميع الخالي من الفلوريد بأنه يقلل فقد الألومنيوم ويسهّل معالجة المياه المستعملة.",
    "منظف مائي لبقايا الشمع والزيوت على القطع المعدنية. يستحلب شمع التلميع والشحوم مع حماية السطح الأساسي.",
    "مضاف للحفر القلوي للألومنيوم مع هيدروكسيد الصوديوم. يعقد أيونات الألومنيوم للحد من التبلور والترسيب واستهلاك الألومنيوم والقلوي.",
    "للحفر الحمضي وإنتاج سطح مطفي قبل الأنودة مع بيفلوريد الأمونيوم. يعدّل النسيج والخشونة لإنتاج مظهر مطفي ناعم ومتجانس.",
    "للتلوين الكهربائي للألومنيوم المؤنود بألوان الشمبانيا والبرونز والأسود. مسحوق يذوب بالماء، يصفه بيانات المنتج بثبات الحمام وتجانس اللون ومقاومة الطقس.",
    "للتلوين الكهربائي بلون ذهبي تيتانيومي فاتح للألومنيوم المؤنود. السائل الشفاف يساعد على ضبط اللون واتساق المظهر الزخرفي.",
    "للتلوين الكهربائي بمظهر ذهب 18 قيراطًا على الألومنيوم الأملس. مادة صلبة سوداء حمراء بمكونات تشتيت وتعقيد وتوصيل؛ 18 قيراطًا وصف للون وليس محتوى طلاء ذهبي.",
    "للتلوين الكهربائي النحاسي الأرجواني للألومنيوم المؤنود، خصوصًا واجهات المباني. مكونات المسحوق الأزرق تساعد على تقليل اختلاف اللون عند الحواف.",
    "لصباغة الألومنيوم المؤنود بالغمر دون تيار كهربائي. ألوان متعددة وإمكانية مطابقة مخصصة؛ يوصي بيانات المنتج بالزخرفة الداخلية.",
    "لإغلاق مسام الألومنيوم المؤنود بدرجة الغرفة. مادة صلبة خضراء فاتحة ذات قدرة تنظيم للحموضة ومقاومة للتزهير المسحوقي؛ يتضمن الجدول أيونات النيكل والفلوريد.",
    "لإغلاق المسام بدرجة متوسطة بعد الأنودة والصباغة لتحسين مقاومة التآكل والاحتكاك والحد من التزهير. يتضمن جدول التحكم أيونات النيكل.",
    "عامل إغلاق مسام خالٍ من النيكل بدرجة متوسطة. غير مذكور في بيانات المنتج؛ يرجى التأكيد مع بنشان."
  ],
  "th": [
    "สารเติมแต่งในบ่ออโนไดซ์อะลูมิเนียมเพื่อเร่งการเกิดฟิล์มออกไซด์ ข้อมูลผลิตภัณฑ์ระบุว่าใช้เวลาน้อยลงและรองรับช่วงอุณหภูมิกว้างขึ้น ให้ฟิล์มสม่ำเสมอสำหรับทำสีหรือย้อมสีต่อไป",
    "เตรียมผิวอะลูมิเนียมพ่นทรายโดยรวมการขจัดน้ำมัน กัดด่าง และปรับสภาพ เหมาะกับชิ้นงานที่มีน้ำมันมาก ช่วยทำความสะอาด เพิ่มความเงา และลดขั้นตอนแยก",
    "ระบบทำสีดำด้วยไฟฟ้าแบบไร้ดีบุกสำหรับอะลูมิเนียมอโนไดซ์ ข้อมูลผลิตภัณฑ์ระบุสีดำมุกสม่ำเสมอบนฟิล์มประมาณ 10 μm โดยไม่เติมดีบุก(II)ซัลเฟต",
    "ขจัดคราบดำหลังการกัดด่างหรือกัดกรดอะลูมิเนียม ช่วยทำความสะอาดและเพิ่มความสว่างก่อนอโนไดซ์",
    "ระบบปิดผนึกไร้นิกเกิลที่อุณหภูมิห้อง ใช้ส่วน A แบบของแข็งร่วมกับ B แบบของเหลว เน้นความคงตัว ความทนต่อสิ่งเจือปน และการดูแลบ่อที่ง่าย",
    "ขจัดน้ำมันก่อนพ่นสีฝุ่นหรืออโนไดซ์อะลูมิเนียม สารลดแรงตึงผิวและสารอิมัลซิไฟเออร์ช่วยกำจัดน้ำมัน สิ่งสกปรก และฟิล์มออกไซด์ตามธรรมชาติ",
    "เคลือบแปลงสภาพโครเมียมก่อนพ่นสีฝุ่น สร้างฟิล์มสีเหลืองอ่อนที่อุณหภูมิห้องเพื่อเพิ่มความทนการกัดกร่อนและการยึดเกาะของสี",
    "เคลือบแปลงสภาพไร้โครเมียมก่อนพ่นสีฝุ่น สร้างฟิล์มใสที่อุณหภูมิห้องเพื่อเพิ่มความทนการกัดกร่อนและการยึดเกาะกับสี",
    "ลอกสีและสารเคลือบจากเหล็กและสเตนเลส โดยเฉพาะสีฝุ่นที่แข็งตัวบนตะขอและอุปกรณ์จับยึด วัสดุสองประเภทนี้เป็นการใช้งานหลักตามข้อมูลผลิตภัณฑ์",
    "สารเติมแต่งขัดเงาสองกรดสำหรับอะลูมิเนียมเงา พ่นทราย และลายขัด ใช้กับกรดฟอสฟอริกและซัลฟิวริก ข้อมูลผลิตภัณฑ์ระบุสูตรไร้กรดไนตริกเพื่อผิวเรียบและบ่อที่เสถียร",
    "ขจัดน้ำมันก่อนพ่นสีฝุ่นหรืออโนไดซ์อะลูมิเนียม สารลดแรงตึงผิวและสารอิมัลซิไฟเออร์ช่วยกำจัดน้ำมัน สิ่งสกปรก และฟิล์มออกไซด์ตามธรรมชาติ",
    "ทำความสะอาดและเพิ่มความเงาอะลูมิเนียมด้วยการกำจัดน้ำมัน สิ่งสกปรก และออกไซด์ธรรมชาติ สูตรไร้ฟลูออไรด์ถูกระบุว่าช่วยลดการสูญเสียอะลูมิเนียมและจัดการน้ำเสียได้ง่ายขึ้น",
    "น้ำยาทำความสะอาดชนิดน้ำสำหรับคราบแว็กซ์และน้ำมันบนโลหะ ช่วยทำอิมัลชันคราบแว็กซ์ขัดเงาและไขมัน พร้อมปกป้องผิวชิ้นงาน",
    "สารเติมแต่งกัดด่างอะลูมิเนียมใช้ร่วมกับโซเดียมไฮดรอกไซด์ จับไอออนอะลูมิเนียมเพื่อลดการตกผลึก ตะกอน และการใช้ด่างหรือสูญเสียเนื้ออะลูมิเนียม",
    "กัดกรดสร้างผิวด้านก่อนอโนไดซ์ร่วมกับแอมโมเนียมไบฟลูออไรด์ ปรับเนื้อผิวและความหยาบให้ได้ผิวด้านละเอียดสม่ำเสมอ",
    "ทำสีด้วยไฟฟ้าหลังอโนไดซ์ ได้สีแชมเปญ บรอนซ์ และดำ เป็นผงละลายน้ำ โดยข้อมูลผลิตภัณฑ์เน้นความเสถียรและสีสม่ำเสมอ",
    "ทำสีทองไทเทเนียมอ่อนด้วยไฟฟ้าบนอะลูมิเนียมอโนไดซ์ ของเหลวใสช่วยควบคุมสีและความสม่ำเสมอของงานตกแต่ง",
    "ทำสีด้วยไฟฟ้าให้มีลักษณะทอง 18K บนผิวเรียบ ของแข็งสีดำแดงมีสารช่วยกระจายตัว จับเชิงซ้อน และนำไฟฟ้า คำว่า 18K หมายถึงสี ไม่ใช่ปริมาณทองที่ชุบ",
    "ทำสีทองแดงม่วงด้วยไฟฟ้าบนอะลูมิเนียมอโนไดซ์ โดยเฉพาะผนังภายนอกอาคาร ส่วนผสมในผงสีน้ำเงินช่วยลดสีต่างบริเวณขอบ",
    "ย้อมอะลูมิเนียมอโนไดซ์ด้วยการจุ่มโดยไม่ใช้กระแสไฟฟ้า มีหลายสีและปรับสีตามต้องการ ข้อมูลผลิตภัณฑ์แนะนำสำหรับงานตกแต่งภายใน",
    "ปิดผนึกอะลูมิเนียมอโนไดซ์ที่อุณหภูมิห้อง ของแข็งสีเขียวอ่อนมีคุณสมบัติบัฟเฟอร์และลดคราบผง ตารางระบุไอออนนิกเกิลและฟลูออไรด์",
    "ปิดผนึกอุณหภูมิปานกลางหลังอโนไดซ์และย้อมสี เพื่อปิดรูพรุน เพิ่มความทนการกัดกร่อนและสึกหรอ พร้อมลดคราบผง ตารางระบุไอออนนิกเกิล",
    "สารปิดผนึกไร้นิกเกิลอุณหภูมิปานกลาง. ข้อมูลผลิตภัณฑ์ไม่ระบุ โปรดยืนยันกับ Benshan"
  ],
  "fil": [
    "Additive sa anodizing bath ng aluminyo na nagpapabilis sa pagbuo ng oxide film. Ayon sa impormasyon ng produkto, mas maikli ang proseso at mas malawak ang temperatura, na may pantay na base para sa pagkukulay o dyeing.",
    "Paunang paggamot sa sandblasted aluminum na pinagsasama ang pag-alis ng langis, alkaline etching, at neutralization. Para lalo sa mamantikang profile, nililinis at pinapaliwanag nito ang ibabaw habang binabawasan ang magkakahiwalay na yugto.",
    "Sistemang walang lata para sa itim na electrolytic coloring ng anodized aluminum. Inilalarawan ng impormasyon ng produkto ang pantay na pearl black sa film na humigit-kumulang 10 μm nang walang stannous sulfate.",
    "Pang-alis ng maitim na residue pagkatapos ng alkaline o acid etching. Nililinis at pinapaliwanag ang aluminyo bago ang anodizing.",
    "Pagseselyong walang nickel sa temperatura ng silid gamit ang solid A at liquid B. Binibigyang-diin ng impormasyon ng produkto ang matatag na sealing, pagtitiis sa dumi sa bath, at simpleng maintenance.",
    "Pag-alis ng langis bago ang powder coating o anodizing. Tinatanggal ng surfactant at emulsifier ang grasa, dumi, at natural oxide film sa aluminyo.",
    "Chromium conversion bago ang powder coating ng aluminyo. Bumubuo ng mapusyaw na dilaw na film sa temperatura ng silid upang mapahusay ang resistensiya sa corrosion at kapit ng coating.",
    "Conversion na walang chromium bago ang powder coating. Bumubuo ng malinaw na film sa temperatura ng silid para sa mas mahusay na kapit at resistensiya sa corrosion.",
    "Pang-alis ng pintura at coating sa bakal at stainless steel, lalo na ang tumigas na powder coating sa hanger at fixture. Ito ang pangunahing substrate sa paglalarawan ng impormasyon ng produkto.",
    "Additive sa dual-acid polishing para sa makintab, sandblasted, at brushed aluminum sa phosphoric/sulfuric acid system. Inilalarawan itong walang nitric acid para sa makinis na finish at matatag na bath.",
    "Pag-alis ng langis bago ang powder coating o anodizing. Tinatanggal ng surfactant at emulsifier ang grasa, dumi, at natural oxide film sa aluminyo.",
    "Panglinis at pampaliwanag ng aluminyo na nag-aalis ng grasa, dumi, at natural oxide. Ang fluoride-free polishing agent ay inilalarawang nakababawas ng pagkawala ng aluminyo at nagpapadali sa paggamot ng wastewater.",
    "Water-based cleaner para sa wax at langis sa metal. Ini-emulsify ang polishing wax at grasa habang pinoprotektahan ang ibabaw ng piyesa.",
    "Additive sa alkaline etching ng aluminyo kasama ang sodium hydroxide. Kinokompleks ang aluminum ions upang mabawasan ang kristal, latak, at konsumo ng aluminyo at alkali.",
    "Acid etching at matting bago ang anodizing kasama ang ammonium bifluoride. Inaayos ang tekstura at gaspang para sa pino at pantay na matte finish.",
    "Electrolytic coloring ng anodized aluminum sa champagne, bronze, at itim. Powder na natutunaw sa tubig, na inilalarawang may matatag na bath at pantay na kulay.",
    "Electrolytic coloring na light titanium gold sa anodized aluminum. Ang malinaw na likido ay tumutulong sa kontrol at pagkakapareho ng dekoratibong kulay.",
    "Golden electrolytic coloring na may 18K-gold na hitsura sa makinis na aluminyo. Ang black-red solid ay may dispersing, complexing at conductive components; kulay ang 18K, hindi dami ng gintong plating.",
    "Purple-copper electrolytic coloring, lalo para sa panlabas na dekorasyon ng gusali. Tinutulungan ng blue powder na bawasan ang pagkakaiba ng kulay sa gilid.",
    "Immersion dyeing ng anodized aluminum nang walang kuryente. May iba’t ibang matingkad at custom na kulay; inirerekomenda ng impormasyon ng produkto para sa panloob na dekorasyon.",
    "Pagseselyo ng anodized aluminum sa temperatura ng silid. Light-green solid na may buffering at panlaban sa powdery bloom; kasama sa talahanayan ang nickel at fluoride ions.",
    "Pagseselyo sa katamtamang temperatura matapos anodizing at dyeing upang isara ang pores at mapahusay ang resistensiya sa corrosion at pagkasira. May nickel ions sa control table.",
    "Panselyong walang nickel sa katamtamang temperatura. Wala sa impormasyon ng produkto; kumpirmahin sa Benshan."
  ],
  "es": [
    "Aditivo para baños de anodizado de aluminio que acelera la formación de óxido. El información del producto describe ciclos más cortos y mayor intervalo térmico, con una base uniforme para coloreado electrolítico o teñido.",
    "Pretratamiento de aluminio granallado que combina desengrase, ataque alcalino y neutralización. Especialmente indicado para perfiles con mucho aceite; limpia, abrillanta y reduce etapas separadas.",
    "Sistema sin estaño para coloreado electrolítico negro del aluminio anodizado. El información del producto describe negro perla uniforme con una película de unos 10 μm, sin añadir sulfato de estaño(II).",
    "Elimina residuos oscuros después del ataque alcalino o ácido. Limpia y mejora el brillo del aluminio antes del anodizado.",
    "Sellado sin níquel a temperatura ambiente, mediante componente sólido A y líquido B. El información del producto destaca estabilidad, tolerancia a impurezas y mantenimiento sencillo.",
    "Desengrasa aluminio antes de pintura en polvo o anodizado. Los tensioactivos y emulsionantes eliminan aceite, suciedad y película de óxido natural.",
    "Conversión de cromo antes de pintura en polvo. Forma una película amarilla clara a temperatura ambiente para mejorar resistencia a corrosión y adherencia.",
    "Conversión sin cromo antes de pintura en polvo. Forma una película transparente a temperatura ambiente para mejorar resistencia a corrosión y unión con el recubrimiento.",
    "Elimina pintura y recubrimientos de acero y acero inoxidable, especialmente pintura en polvo curada en ganchos y útiles. Estos son los sustratos principales de la descripción.",
    "Aditivo de pulido con dos ácidos para aluminio brillante, granallado o cepillado, en sistema fosfórico/sulfúrico. El información del producto describe una formulación sin ácido nítrico para superficies lisas y mayor estabilidad.",
    "Desengrasa aluminio antes de pintura en polvo o anodizado. Los tensioactivos y emulsionantes eliminan aceite, suciedad y película de óxido natural.",
    "Limpia y abrillanta aluminio eliminando grasa, suciedad y óxido natural. El agente sin fluoruro se describe como capaz de reducir pérdida de aluminio y facilitar el tratamiento de aguas residuales.",
    "Limpiador acuoso de cera y aceite en piezas metálicas. Emulsiona residuos de cera de pulido y grasa protegiendo la superficie de base.",
    "Aditivo de ataque alcalino con hidróxido de sodio. Compleja iones de aluminio para reducir cristalización, precipitados y consumo de aluminio y sosa.",
    "Ataque ácido para acabado mate antes del anodizado, junto con bifluoruro de amonio. Modifica textura y rugosidad para obtener un mate fino y uniforme.",
    "Coloreado electrolítico del aluminio anodizado en champán, bronce y negro. Polvo soluble en agua descrito como estable y de color uniforme.",
    "Coloreado electrolítico oro titanio claro del aluminio anodizado. El líquido transparente favorece control y uniformidad del color decorativo.",
    "Coloreado electrolítico dorado con apariencia de oro 18K en superficies lisas. Sólido negro rojizo con componentes dispersantes, complejantes y conductores; 18K describe el color, no contenido de oro depositado.",
    "Coloreado electrolítico cobre púrpura, especialmente para exteriores arquitectónicos. Los componentes del polvo azul ayudan a reducir variaciones de color en los bordes.",
    "Teñido por inmersión del aluminio anodizado sin corriente eléctrica. Colores variados y personalizables; el información del producto recomienda decoración interior.",
    "Sellado del aluminio anodizado a temperatura ambiente. Sólido verde claro con capacidad tampón y control de depósitos pulverulentos; la tabla incluye iones níquel y fluoruro.",
    "Sellado a temperatura media tras anodizado y teñido para cerrar poros y mejorar resistencia a corrosión y desgaste. La tabla de control incluye iones níquel.",
    "Sellador sin níquel a temperatura media. No figura en el información del producto; confirme con Benshan."
  ],
  "pt": [
    "Aditivo para banho de anodização de alumínio que acelera a formação de óxido. O informações do produto descreve ciclos menores e maior faixa térmica, com base uniforme para coloração eletrolítica ou tingimento.",
    "Pré-tratamento de alumínio jateado que combina desengraxe, ataque alcalino e neutralização. Indicado especialmente para perfis muito oleosos; limpa, abrilhanta e reduz etapas separadas.",
    "Sistema sem estanho para coloração eletrolítica preta de alumínio anodizado. O informações do produto descreve preto perolado uniforme em filme de cerca de 10 μm, sem sulfato de estanho(II).",
    "Remove resíduos escuros após ataque alcalino ou ácido. Limpa e melhora o brilho do alumínio antes da anodização.",
    "Selagem sem níquel à temperatura ambiente, com componente sólido A e líquido B. O informações do produto destaca estabilidade, tolerância a impurezas e manutenção simples.",
    "Desengraxa alumínio antes da pintura a pó ou anodização. Tensoativos e emulsificantes removem óleo, sujeira e filme de óxido natural.",
    "Conversão de cromo antes da pintura a pó. Forma filme amarelo-claro à temperatura ambiente para melhorar resistência à corrosão e aderência.",
    "Conversão sem cromo antes da pintura a pó. Forma filme transparente à temperatura ambiente para melhorar resistência à corrosão e ligação ao revestimento.",
    "Remove tintas e revestimentos de aço e aço inoxidável, especialmente pintura a pó curada em ganchos e dispositivos. Esses são os substratos principais da descrição.",
    "Aditivo de polimento com dois ácidos para alumínio brilhante, jateado ou escovado em sistema fosfórico/sulfúrico. O informações do produto descreve fórmula sem ácido nítrico para superfícies lisas e estabilidade do banho.",
    "Desengraxa alumínio antes da pintura a pó ou anodização. Tensoativos e emulsificantes removem óleo, sujeira e filme de óxido natural.",
    "Limpa e abrilhanta alumínio removendo óleo, sujeira e óxido natural. O agente sem fluoreto é descrito como redutor de perda de alumínio e facilitador do tratamento de efluentes.",
    "Limpador aquoso para cera e óleo em peças metálicas. Emulsifica resíduos de cera de polimento e graxa enquanto protege a superfície.",
    "Aditivo de ataque alcalino com hidróxido de sódio. Complexa íons de alumínio para reduzir cristalização, precipitados e consumo de alumínio e soda.",
    "Ataque ácido para acabamento fosco antes da anodização, com bifluoreto de amônio. Modifica textura e rugosidade para produzir fosco fino e uniforme.",
    "Coloração eletrolítica de alumínio anodizado em champanhe, bronze e preto. Pó solúvel em água descrito como estável e de coloração uniforme.",
    "Coloração eletrolítica ouro titânio claro em alumínio anodizado. O líquido transparente favorece controle e uniformidade da cor decorativa.",
    "Coloração eletrolítica dourada com aparência de ouro 18K em superfícies lisas. Sólido preto-avermelhado com dispersantes, complexantes e condutores; 18K descreve a cor, não teor de ouro depositado.",
    "Coloração eletrolítica cobre púrpura, especialmente para exteriores arquitetônicos. Os componentes do pó azul ajudam a reduzir diferenças de cor nas bordas.",
    "Tingimento por imersão de alumínio anodizado sem corrente elétrica. Cores variadas e personalizadas; o informações do produto recomenda decoração interna.",
    "Selagem de alumínio anodizado à temperatura ambiente. Sólido verde-claro com capacidade tampão e controle de manchas pulverulentas; a tabela inclui íons níquel e fluoreto.",
    "Selagem à temperatura média após anodização e tingimento para fechar poros e melhorar resistência à corrosão e desgaste. A tabela de controle inclui íons níquel.",
    "Selante sem níquel à temperatura média. Não consta no informações do produto; confirme com a Benshan."
  ],
  "bn": [
    "অ্যালুমিনিয়াম অ্যানোডাইজিং বাথে অক্সাইড ফিল্ম দ্রুত গঠনের উপাদান। পণ্যের তথ্যে কম সময় ও বিস্তৃত তাপমাত্রা সীমার কথা বলা হয়েছে, যা পরবর্তী রং বা ডাইংয়ের জন্য সমান ভিত্তি দেয়।",
    "স্যান্ডব্লাস্ট করা অ্যালুমিনিয়ামের প্রাথমিক প্রক্রিয়ায় তেল অপসারণ, ক্ষারীয় এচিং ও নিরপেক্ষকরণ একত্র করে। বেশি তেলযুক্ত প্রোফাইল পরিষ্কার ও উজ্জ্বল করে এবং আলাদা ধাপ কমায়।",
    "অ্যানোডাইজড অ্যালুমিনিয়ামে কালো ইলেক্ট্রোলাইটিক রঙের টিনমুক্ত ব্যবস্থা। পণ্যের তথ্যে প্রায় 10 μm ফিল্মে সমান পার্ল-ব্ল্যাক রং এবং টিন(II) সালফেট না লাগার কথা রয়েছে।",
    "ক্ষারীয় বা অ্যাসিড এচিংয়ের পর কালো অবশিষ্টাংশ সরায়। পরবর্তী অ্যানোডাইজিংয়ের আগে অ্যালুমিনিয়াম পরিষ্কার ও উজ্জ্বল করে।",
    "ঘরের তাপমাত্রায় নিকেলমুক্ত সিলিং ব্যবস্থা, কঠিন A ও তরল B উপাদান ব্যবহার করে। পণ্যের তথ্যে স্থিতিশীলতা, অমিশ্রণ সহনশীলতা ও সহজ রক্ষণাবেক্ষণের কথা রয়েছে।",
    "পাউডার কোটিং বা অ্যানোডাইজিংয়ের আগে তেল পরিষ্কার করে। সার্ফ্যাক্ট্যান্ট ও ইমালসিফায়ার তেল, ময়লা ও প্রাকৃতিক অক্সাইড ফিল্ম সরায়।",
    "পাউডার কোটিংয়ের আগে ক্রোমিয়াম কনভার্সন প্রক্রিয়া। ঘরের তাপমাত্রায় হালকা হলুদ ফিল্ম তৈরি করে ক্ষয় প্রতিরোধ ও কোটিংয়ের বন্ধন উন্নত করে।",
    "পাউডার কোটিংয়ের আগে ক্রোমিয়ামমুক্ত কনভার্সন প্রক্রিয়া। ঘরের তাপমাত্রায় স্বচ্ছ ফিল্ম তৈরি করে ক্ষয় প্রতিরোধ ও কোটিংয়ের বন্ধন উন্নত করে।",
    "ইস্পাত ও স্টেইনলেস স্টিল থেকে রং ও কোটিং সরায়, বিশেষত হ্যাঙ্গার ও ফিক্সচারের শক্ত পাউডার কোটিং। পণ্যের তথ্যের মূল প্রয়োগ এই দুই ধরনের ধাতুতে।",
    "ফসফরিক/সালফিউরিক অ্যাসিড ব্যবস্থায় চকচকে, স্যান্ডব্লাস্ট বা ব্রাশড অ্যালুমিনিয়াম পলিশ করে। পণ্যের তথ্যে নাইট্রিক অ্যাসিডমুক্ত সূত্র, মসৃণ ফিনিশ ও বাথের স্থিতিশীলতার কথা রয়েছে।",
    "পাউডার কোটিং বা অ্যানোডাইজিংয়ের আগে তেল পরিষ্কার করে। সার্ফ্যাক্ট্যান্ট ও ইমালসিফায়ার তেল, ময়লা ও প্রাকৃতিক অক্সাইড ফিল্ম সরায়।",
    "তেল, ময়লা ও প্রাকৃতিক অক্সাইড সরিয়ে অ্যালুমিনিয়াম পরিষ্কার ও উজ্জ্বল করে। ফ্লোরাইডমুক্ত উপাদানটি অ্যালুমিনিয়াম ক্ষয় কমানো ও বর্জ্যজল প্রক্রিয়া সহজ করার জন্য বর্ণিত।",
    "ধাতুর মোম ও তেলের জন্য জলভিত্তিক পরিষ্কারক। পলিশিং মোম ও তেল ইমালসিফাই করে এবং মূল পৃষ্ঠতল রক্ষা করে।",
    "সোডিয়াম হাইড্রক্সাইডের সঙ্গে অ্যালুমিনিয়ামের ক্ষারীয় এচিংয়ে ব্যবহৃত হয়। অ্যালুমিনিয়াম আয়ন জটিলবন্ধনে ধরে স্ফটিক, তলানি ও ক্ষার-অ্যালুমিনিয়াম খরচ কমায়।",
    "অ্যানোডাইজিংয়ের আগে অ্যামোনিয়াম বাইফ্লোরাইডের সঙ্গে অ্যাসিড এচিং করে। পৃষ্ঠের গঠন ও রুক্ষতা বদলে সূক্ষ্ম সমান ম্যাট ফিনিশ দেয়।",
    "অ্যানোডাইজড অ্যালুমিনিয়ামে শ্যাম্পেন, ব্রোঞ্জ ও কালো ইলেক্ট্রোলাইটিক রং দেয়। জলে দ্রবণীয় গুঁড়া; পণ্যের তথ্যে স্থিতিশীল বাথ ও সমান রঙের কথা আছে।",
    "অ্যানোডাইজড অ্যালুমিনিয়ামে হালকা টাইটানিয়াম-সোনালি ইলেক্ট্রোলাইটিক রং দেয়। স্বচ্ছ তরলটি সাজসজ্জার রং নিয়ন্ত্রণ ও সামঞ্জস্যে সহায়তা করে।",
    "মসৃণ অ্যালুমিনিয়ামে 18K সোনালি চেহারার ইলেক্ট্রোলাইটিক রং দেয়। কালচে লাল কঠিন পদার্থে বিচ্ছুরক ও পরিবাহী উপাদান আছে; 18K রঙের নাম, সোনার প্রলেপের পরিমাণ নয়।",
    "অ্যানোডাইজড অ্যালুমিনিয়ামে বেগুনি-তামাটে রং, বিশেষত ভবনের বাইরের সাজসজ্জায়। নীল গুঁড়ার উপাদান প্রান্তে রঙের পার্থক্য কমাতে সাহায্য করে।",
    "বিদ্যুৎ ছাড়া অ্যানোডাইজড অ্যালুমিনিয়াম ডুবিয়ে রং করে। একাধিক ও কাস্টম রং পাওয়া যায়; পণ্যের তথ্যে ঘরের ভেতরের সাজসজ্জা সুপারিশ করা হয়েছে।",
    "ঘরের তাপমাত্রায় অ্যানোডাইজড অ্যালুমিনিয়াম সিল করে। হালকা সবুজ কঠিন পদার্থে বাফারিং ও গুঁড়া দাগ নিয়ন্ত্রণের বৈশিষ্ট্য; সারণিতে নিকেল ও ফ্লোরাইড আয়ন আছে।",
    "অ্যানোডাইজিং ও রঙের পর মাঝারি তাপমাত্রায় ছিদ্র বন্ধ করে ক্ষয় ও ঘর্ষণ প্রতিরোধ উন্নত করে। নিয়ন্ত্রণ সারণিতে নিকেল আয়ন আছে।",
    "মাঝারি তাপমাত্রায় নিকেলমুক্ত সিলিং উপাদান. পণ্যের তথ্যে দেওয়া নেই; বেনশানের কাছে নিশ্চিত করুন।"
  ],
  "hi": [
    "एल्युमिनियम एनोडाइजिंग बाथ में ऑक्साइड फिल्म तेज़ी से बनाने वाला योजक। उत्पाद जानकारी कम समय और व्यापक तापमान सीमा बताता है, जिससे आगे इलेक्ट्रोलाइटिक रंगाई या डाइंग के लिए समान आधार मिलता है।",
    "सैंडब्लास्ट एल्युमिनियम का पूर्व-उपचार, जिसमें तेल हटाना, क्षारीय एचिंग और न्यूट्रलाइज़ेशन शामिल हैं। अधिक तेल वाले प्रोफाइल को साफ और चमकीला बनाते हुए अलग चरण कम करता है।",
    "एनोडाइज्ड एल्युमिनियम की काली इलेक्ट्रोलाइटिक रंगाई के लिए टिन-मुक्त प्रणाली। उत्पाद जानकारी लगभग 10 μm फिल्म पर समान पर्ल-ब्लैक रंग बताता है, बिना टिन(II) सल्फेट जोड़े।",
    "क्षारीय या अम्लीय एचिंग के बाद काले अवशेष हटाता है। अगली एनोडाइजिंग से पहले एल्युमिनियम को साफ और चमकीला बनाता है।",
    "कमरे के तापमान पर निकेल-मुक्त सीलिंग, ठोस A और तरल B घटकों के साथ। उत्पाद जानकारी स्थिर प्रदर्शन, बाथ की अशुद्धियों की सहनशीलता और आसान रखरखाव बताता है।",
    "पाउडर कोटिंग या एनोडाइजिंग से पहले तेल हटाता है। सर्फैक्टैंट और इमल्सीफायर तेल, गंदगी और प्राकृतिक ऑक्साइड फिल्म साफ करते हैं।",
    "पाउडर कोटिंग से पहले क्रोमियम कन्वर्ज़न उपचार। कमरे के तापमान पर हल्की पीली फिल्म बनाकर संक्षारण प्रतिरोध और कोटिंग का चिपकाव सुधारता है।",
    "पाउडर कोटिंग से पहले क्रोमियम-मुक्त कन्वर्ज़न उपचार। कमरे के तापमान पर पारदर्शी फिल्म बनाकर संक्षारण प्रतिरोध और कोटिंग का बंधन सुधारता है।",
    "इस्पात और स्टेनलेस स्टील से पेंट व कोटिंग हटाता है, विशेषकर हैंगर और फिक्स्चर पर जमी पाउडर कोटिंग। उत्पाद जानकारी के मुख्य आधार पदार्थ यही हैं।",
    "फॉस्फोरिक/सल्फ्यूरिक अम्ल प्रणाली में चमकदार, सैंडब्लास्ट और ब्रश्ड एल्युमिनियम की दो-अम्ल पॉलिशिंग। उत्पाद जानकारी नाइट्रिक-अम्ल-मुक्त सूत्र से चिकनी सतह और बाथ स्थिरता बताता है।",
    "पाउडर कोटिंग या एनोडाइजिंग से पहले तेल हटाता है। सर्फैक्टैंट और इमल्सीफायर तेल, गंदगी और प्राकृतिक ऑक्साइड फिल्म साफ करते हैं।",
    "तेल, गंदगी और प्राकृतिक ऑक्साइड हटाकर एल्युमिनियम को साफ और चमकीला करता है। फ्लोराइड-मुक्त एजेंट को कम एल्युमिनियम हानि और आसान अपशिष्टजल उपचार के लिए वर्णित किया गया है।",
    "धातु के मोम और तेल अवशेषों के लिए जल-आधारित क्लीनर। पॉलिशिंग मोम और ग्रीस को इमल्सीफाई करते हुए मूल सतह की रक्षा करता है।",
    "सोडियम हाइड्रॉक्साइड के साथ एल्युमिनियम की क्षारीय एचिंग का योजक। एल्युमिनियम आयनों को कॉम्प्लेक्स करके क्रिस्टल, अवक्षेप और क्षार व एल्युमिनियम की खपत कम करता है।",
    "एनोडाइजिंग से पहले अमोनियम बाइफ्लोराइड के साथ अम्लीय एचिंग। बनावट और खुरदरापन बदलकर महीन, समान मैट फिनिश देता है।",
    "एनोडाइज्ड एल्युमिनियम में शैम्पेन, कांस्य और काली इलेक्ट्रोलाइटिक रंगाई। पानी में घुलने वाला पाउडर, जिसे स्थिर बाथ और समान रंग के लिए वर्णित किया गया है।",
    "एनोडाइज्ड एल्युमिनियम पर हल्की टाइटेनियम-गोल्ड इलेक्ट्रोलाइटिक रंगाई। पारदर्शी तरल सजावटी रंग के नियंत्रण और एकरूपता में सहायता करता है।",
    "चिकनी सतह पर 18K सोने जैसी इलेक्ट्रोलाइटिक रंगाई। काले-लाल ठोस में फैलाव, कॉम्प्लेक्सिंग और चालक घटक हैं; 18K रंग का वर्णन है, जमा सोने की मात्रा नहीं।",
    "एनोडाइज्ड एल्युमिनियम पर बैंगनी-तांबे की इलेक्ट्रोलाइटिक रंगाई, विशेषकर भवनों के बाहरी हिस्सों में। नीले पाउडर के घटक किनारों के रंग-अंतर को कम करने में मदद करते हैं।",
    "बिना विद्युत धारा के एनोडाइज्ड एल्युमिनियम की डुबोकर रंगाई। कई और अनुकूलित रंग उपलब्ध हैं; उत्पाद जानकारी आंतरिक सजावट का उपयोग सुझाता है।",
    "कमरे के तापमान पर एनोडाइज्ड एल्युमिनियम की सीलिंग। हल्के हरे ठोस में बफरिंग और पाउडरी दाग नियंत्रण के गुण हैं; तालिका में निकेल और फ्लोराइड आयन हैं।",
    "एनोडाइजिंग और रंगाई के बाद मध्यम तापमान पर छिद्र बंद करके संक्षारण और घिसाव प्रतिरोध सुधारता है। नियंत्रण तालिका में निकेल आयन हैं।",
    "मध्यम तापमान पर निकेल-मुक्त सीलिंग. उत्पाद जानकारी में नहीं दिया; बेनशान से पुष्टि करें।"
  ]
};
