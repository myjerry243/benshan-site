const productCode=document.body.dataset.product;
document.querySelector('#product-language').addEventListener('change',e=>{
 const language=e.target.value;try{localStorage.setItem('benshan-language',language)}catch{}
 const u=new URL(location.href);u.pathname='/benshan-site/'+language+'/products/'+productCode.toLowerCase()+'/';location.href=u.href;
});
// Carry campaign attribution into the inquiry; sending remains a visitor action.
document.querySelectorAll('.inquiry-link').forEach(a=>{
 const u=new URL(a.href),current=new URLSearchParams(location.search);
 for(const key of ['utm_source','utm_medium','utm_campaign'])if(current.has(key))u.searchParams.set(key,current.get(key).slice(0,200));
 a.href=u.href;
});
